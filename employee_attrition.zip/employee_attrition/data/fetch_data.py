"""
data/fetch_data.py
Cliente centralizado para la API de CryptoCompare.
FIX v2:
  - Cada símbolo usa semilla única (_sym_seed) → series históricas distintas
  - La correlación sintética ahora muestra valores reales (-1 a 1)
  - 30 monedas en el fallback
  - fetch_multi_histoday usa interpolación para evitar NaN
"""

import time
import hashlib
import requests
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

BASE_URL  = "https://min-api.cryptocompare.com/data"
HEADERS   = {"Accept": "application/json"}
CACHE_TTL = 300

_cache: dict = {}


def fetch_top_coins(limit: int = 50, tsym: str = "USD") -> pd.DataFrame:
    rows = []
    per_page = 100
    pages_needed = max(1, -(-limit // per_page))
    for page in range(pages_needed):
        url    = f"{BASE_URL}/top/mktcapfull"
        params = {"limit": min(per_page, limit - page * per_page), "tsym": tsym, "page": page}
        try:
            resp = requests.get(url, params=params, headers=HEADERS, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            if data.get("Response") != "Success":
                break
            for item in data.get("Data", []):
                coin = item.get("CoinInfo", {})
                raw  = item.get("RAW", {}).get(tsym, {})
                if not raw:
                    continue
                rows.append({
                    "symbol"        : coin.get("Name", ""),
                    "name"          : coin.get("FullName", ""),
                    "price"         : raw.get("PRICE", 0),
                    "market_cap"    : raw.get("MKTCAP", 0),
                    "volume_24h"    : raw.get("VOLUME24HOURTO", 0),
                    "change_24h"    : raw.get("CHANGE24HOUR", 0),
                    "change_pct_24h": raw.get("CHANGEPCT24HOUR", 0),
                    "high_24h"      : raw.get("HIGH24HOUR", 0),
                    "low_24h"       : raw.get("LOW24HOUR", 0),
                    "open_24h"      : raw.get("OPEN24HOUR", 0),
                    "supply"        : raw.get("SUPPLY", 0),
                    "algo"          : coin.get("Algorithm", "N/A"),
                })
        except Exception:
            break
    if rows:
        return pd.DataFrame(rows).head(limit)
    return _synthetic_top_coins(limit)


def get_top_coins_cached(limit: int = 50) -> pd.DataFrame:
    key = f"top_{limit}"
    now = time.time()
    if key in _cache and (now - _cache[key]["ts"]) < CACHE_TTL:
        return _cache[key]["data"]
    df = fetch_top_coins(limit)
    _cache[key] = {"ts": now, "data": df}
    return df


def fetch_histoday(symbol: str = "BTC", tsym: str = "USD", days: int = 90) -> pd.DataFrame:
    url    = f"{BASE_URL}/v2/histoday"
    params = {"fsym": symbol, "tsym": tsym, "limit": days}
    try:
        resp = requests.get(url, params=params, headers=HEADERS, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        if data.get("Response") != "Success":
            return _synthetic_histoday(symbol, days)
        entries = data.get("Data", {}).get("Data", [])
        if not entries:
            return _synthetic_histoday(symbol, days)
        df = pd.DataFrame(entries)
        df["date"] = pd.to_datetime(df["time"], unit="s")
        df = df.rename(columns={"volumeto": "volume"})[
            ["date", "open", "high", "low", "close", "volume"]
        ]
        return df.sort_values("date").reset_index(drop=True)
    except Exception:
        return _synthetic_histoday(symbol, days)


def fetch_multi_histoday(symbols: list, tsym: str = "USD", days: int = 60) -> pd.DataFrame:
    frames = {}
    for sym in symbols:
        df = fetch_histoday(sym, tsym, days)
        if not df.empty and "close" in df.columns:
            s = df.set_index("date")["close"].replace(0, np.nan)
            frames[sym] = s
    if not frames:
        return pd.DataFrame()
    combined = pd.DataFrame(frames).interpolate(method="linear").dropna()
    combined.index.name = "date"
    return combined.reset_index()


def fetch_global_stats() -> dict:
    df = get_top_coins_cached(limit=100)
    if df.empty:
        return {}
    total_mcap = df["market_cap"].sum()
    btc_mcap   = df.loc[df["symbol"] == "BTC", "market_cap"].sum()
    eth_mcap   = df.loc[df["symbol"] == "ETH", "market_cap"].sum()
    return {
        "total_market_cap"  : total_mcap,
        "btc_dominance"     : (btc_mcap / total_mcap * 100) if total_mcap else 0,
        "eth_dominance"     : (eth_mcap / total_mcap * 100) if total_mcap else 0,
        "total_volume_24h"  : df["volume_24h"].sum(),
        "coins_tracked"     : len(df),
        "avg_change_pct_24h": df["change_pct_24h"].mean(),
    }


# ── 30 monedas sintéticas ────────────────────────────────────────────────────
_SYNTH_COINS = [
    ("BTC",   "Bitcoin",            95000,  1850e9),
    ("ETH",   "Ethereum",            3200,   385e9),
    ("USDT",  "Tether",              1.00,   140e9),
    ("BNB",   "BNB",                  650,    95e9),
    ("SOL",   "Solana",               185,    87e9),
    ("XRP",   "XRP",                 2.50,   143e9),
    ("USDC",  "USD Coin",             1.00,    45e9),
    ("ADA",   "Cardano",              1.10,    39e9),
    ("AVAX",  "Avalanche",            40,     17e9),
    ("DOGE",  "Dogecoin",            0.38,    56e9),
    ("DOT",   "Polkadot",             10,      9e9),
    ("LINK",  "Chainlink",            20,     12e9),
    ("MATIC", "Polygon",             0.55,     5e9),
    ("LTC",   "Litecoin",             95,      7e9),
    ("SHIB",  "Shiba Inu",       0.000025,    15e9),
    ("TRX",   "TRON",               0.24,    21e9),
    ("UNI",   "Uniswap",              12,      7e9),
    ("ATOM",  "Cosmos",               10,      4e9),
    ("XMR",   "Monero",              165,      3e9),
    ("ETC",   "Ethereum Classic",     30,      4e9),
    ("FIL",   "Filecoin",              6,      3e9),
    ("HBAR",  "Hedera",             0.12,      5e9),
    ("ICP",   "Internet Computer",   12,       5e9),
    ("VET",   "VeChain",           0.045,      4e9),
    ("ALGO",  "Algorand",           0.22,      2e9),
    ("XLM",   "Stellar",            0.12,      3e9),
    ("NEAR",  "NEAR Protocol",        6,       7e9),
    ("APT",   "Aptos",               12,       5e9),
    ("ARB",   "Arbitrum",            1.20,      5e9),
    ("OP",    "Optimism",            2.50,      3e9),
]


def _sym_seed(symbol: str) -> int:
    """Semilla determinista única por símbolo."""
    return int(hashlib.md5(symbol.encode()).hexdigest(), 16) % (2**31)


def _synthetic_top_coins(limit: int = 50) -> pd.DataFrame:
    rows = []
    for sym, name, base_price, base_mcap in _SYNTH_COINS[:min(limit, len(_SYNTH_COINS))]:
        rng        = np.random.default_rng(_sym_seed(sym) + int(time.time() // 300))
        noise      = rng.uniform(0.93, 1.07)
        price      = base_price * noise
        change_pct = rng.uniform(-10, 10)
        rows.append({
            "symbol"        : sym,
            "name"          : name,
            "price"         : price,
            "market_cap"    : base_mcap * noise,
            "volume_24h"    : base_mcap * rng.uniform(0.02, 0.18),
            "change_24h"    : price * change_pct / 100,
            "change_pct_24h": change_pct,
            "high_24h"      : price * rng.uniform(1.01, 1.06),
            "low_24h"       : price * rng.uniform(0.94, 0.99),
            "open_24h"      : price * (1 - change_pct / 100),
            "supply"        : base_mcap / max(price, 1e-9),
            "algo"          : "SHA256" if sym == "BTC" else "Various",
        })
    return pd.DataFrame(rows)


def _synthetic_histoday(symbol: str, days: int) -> pd.DataFrame:
    """
    Caminata aleatoria con semilla ÚNICA por símbolo.
    Esto garantiza que la matriz de correlación tenga valores
    realistas (distintos de 1.0 o NaN) cuando se usa el fallback.
    """
    base_prices = {
        "BTC": 95000, "ETH": 3200,  "BNB": 650,  "SOL": 185,
        "XRP": 2.50,  "ADA": 1.10,  "AVAX": 40,  "DOGE": 0.38,
        "DOT": 10,    "LINK": 20,   "LTC": 95,   "UNI": 12,
        "ATOM": 10,   "XMR": 165,   "TRX": 0.24, "MATIC": 0.55,
        "NEAR": 6,    "ARB": 1.20,  "OP": 2.50,  "APT": 12,
        "HBAR": 0.12, "ICP": 12,    "VET": 0.045,"ALGO": 0.22,
        "XLM":  0.12, "SHIB": 2.5e-5, "USDT": 1.0, "USDC": 1.0,
        "FIL":  6,    "ETC": 30,
    }
    base = base_prices.get(symbol, 1.0)

    seed = _sym_seed(symbol)
    rng  = np.random.default_rng(seed)

    # Cada moneda tiene su propio perfil de drift + volatilidad
    drift = rng.uniform(-0.0015, 0.003)
    vol   = rng.uniform(0.018, 0.065)

    dates   = [datetime.utcnow() - timedelta(days=days - i) for i in range(days + 1)]
    returns = rng.normal(drift, vol, days + 1)

    prices = [base]
    for r in returns[1:]:
        prices.append(max(prices[-1] * (1 + r), base * 0.005))

    opens  = [p * rng.uniform(0.985, 1.005) for p in prices]
    highs  = [max(p * rng.uniform(1.002, 1.06), p) for p in prices]
    lows   = [min(p * rng.uniform(0.94, 0.998), p) for p in prices]
    vols   = [abs(rng.normal(base * 8000, base * 2500)) for _ in prices]

    return pd.DataFrame({
        "date"  : dates,
        "open"  : opens,
        "high"  : highs,
        "low"   : lows,
        "close" : prices,
        "volume": vols,
    })

"""
tabs/metodologia.py
Metodología: descripción del pipeline de datos y del modelo predictivo.
"""

from dash import html
import dash_bootstrap_components as dbc


def layout():
    return dbc.Container([

        html.H2("⚙️ Metodología", className="section-title"),
        html.P(
            "Pipeline técnico completo: desde la obtención de datos "
            "en tiempo real hasta la predicción de señal.",
            className="section-subtitle"
        ),

        # ── Pipeline ─────────────────────────────────────────────────────
        dbc.Card([
            dbc.CardHeader("🔄 Pipeline de Datos y Modelado"),
            dbc.CardBody([_pipeline()])
        ], className="mb-3"),

        # ── Datos ─────────────────────────────────────────────────────────
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader("📡 Fuente de Datos"),
                    dbc.CardBody([
                        html.Table([
                            html.Thead(html.Tr([html.Th("Campo"), html.Th("Valor")])),
                            html.Tbody([
                                html.Tr([html.Td("API"), html.Td(html.Code("CryptoCompare"))]),
                                html.Tr([html.Td("Endpoint mktcap"), html.Td(html.Code("/data/top/mktcapfull"))]),
                                html.Tr([html.Td("Endpoint histórico"), html.Td(html.Code("/data/v2/histoday"))]),
                                html.Tr([html.Td("Moneda base"), html.Td("USD")]),
                                html.Tr([html.Td("Top coins"), html.Td("20")]),
                                html.Tr([html.Td("Días histórico"), html.Td("90")]),
                                html.Tr([html.Td("Caché TTL"), html.Td("300 s (5 min)")]),
                                html.Tr([html.Td("Fallback"), html.Td("Dataset sintético")]),
                            ])
                        ], className="crypto-table")
                    ])
                ])
            ], md=5),

            
        ], className="mb-3"),

        # ── Features del modelo ───────────────────────────────────────────
        dbc.Card([
            dbc.CardHeader("🔧 Feature Engineering"),
            dbc.CardBody([
                dbc.Row([
                    dbc.Col([
                        html.H6("Features del snapshot actual",
                                style={"color": "var(--accent-blue)"}),
                        html.Div([
                            html.Span(f, className="pill pill-blue")
                            for f in ["price", "market_cap", "volume_24h",
                                      "change_pct_24h", "high_24h", "low_24h"]
                        ])
                    ], md=6),
                    dbc.Col([
                        html.H6("Features derivadas",
                                style={"color": "var(--accent-teal)"}),
                        html.Div([
                            html.Span(f, className="pill pill-teal")
                            for f in ["hl_range_pct", "liq_ratio",
                                      "sma_7", "sma_30", "retorno_1d"]
                        ])
                    ], md=6),
                ])
            ])
        ], className="mb-3"),

        # ── Validación ───────────────────────────────────────────────────
        dbc.Card([
            dbc.CardHeader("✅ Estrategia de Validación"),
            dbc.CardBody([
                dbc.Row([
                    dbc.Col(_val("Hold-out 80/20",
                                 "Con estratificación por la señal objetivo.",
                                 "var(--accent-blue)"), md=4),
                    dbc.Col(_val("Métricas duales",
                                 "Accuracy + AUC-ROC para desempeño global.",
                                 "var(--accent-purple)"), md=4),
                    dbc.Col(_val("Fallback sintético",
                                 "Si la API no responde, el modelo se entrena "
                                 "con datos generados para demostración.",
                                 "var(--accent-teal)"), md=4),
                ])
            ])
        ]),

    ], fluid=True, className="py-3")


def _pipeline():
    pasos = [
        ("1", "Fetch API",           "GET /top/mktcapfull → JSON",              "var(--accent-blue)"),
        ("2", "Parseo y caché",      "DataFrame + TTL 5 min en memoria",         "var(--accent-purple)"),
        ("3", "Feature engineering", "hl_range, liq_ratio, sma_7, sma_30",      "var(--accent-teal)"),
        ("4", "Target construction", "señal = int(close > open)",                "var(--accent-orange)"),
        ("5", "Train / Test split",  "80/20 estratificado, seed=42",             "var(--accent-blue)"),
        ("6", "Scaling",             "StandardScaler sobre features numéricas",  "var(--accent-purple)"),
        ("7", "Random Forest",       "200 árboles, max_depth=6",                 "var(--accent-teal)"),
        ("8", "Evaluación",          "Accuracy, Precision, Recall, F1, AUC-ROC","var(--accent-orange)"),
        ("9", "Predicción live",     "Formulario → pipeline.predict_proba()",   "var(--accent-green)"),
    ]
    return html.Div([
        html.Div([
            html.Div([
                html.Span(num, style={
                    "display": "inline-block", "width": "28px", "height": "28px",
                    "borderRadius": "50%", "background": color,
                    "color": "#0d1117", "fontWeight": "700", "textAlign": "center",
                    "lineHeight": "28px", "flexShrink": "0", "fontSize": "0.82rem"
                }),
                html.Div([
                    html.Strong(titulo, style={"color": "var(--text-bright)", "fontSize": "0.88rem"}),
                    html.Span(f"  · {desc}", style={"color": "var(--text-mid)", "fontSize": "0.82rem"})
                ], style={"marginLeft": "12px"})
            ], style={
                "display": "flex", "alignItems": "center",
                "background": "var(--bg-card2)", "borderRadius": "8px",
                "padding": "10px 14px", "marginBottom": "7px",
                "border": "1px solid var(--border)"
            })
        ])
        for num, titulo, desc, color in pasos
    ])


def _val(titulo, desc, color):
    return html.Div([
        html.Strong(titulo, style={"color": color, "fontSize": "0.9rem"}),
        html.P(desc, className="small mb-0 mt-1", style={"color": "var(--text-mid)"})
    ], style={
        "background": "var(--bg-card2)", "borderRadius": "10px",
        "padding": "14px", "border": "1px solid var(--border)"
    })

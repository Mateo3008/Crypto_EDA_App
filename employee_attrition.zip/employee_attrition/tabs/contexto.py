"""
tabs/contexto.py
Pestaña de Contexto: panorama global del mercado cripto con datos en vivo.
"""

import sys, os
import pandas as pd
import plotly.express as px
from dash import html, dcc
import dash_bootstrap_components as dbc

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "data"))
from fetch_data import get_top_coins_cached, fetch_global_stats


def layout():
    df    = get_top_coins_cached(limit=20)
    stats = fetch_global_stats()

    return dbc.Container([

        html.H2("🌍 Contexto del Mercado Cripto", className="section-title"),
        html.P(
            "Panorama global en tiempo real: capitalización, dominancia y volumen.",
            className="section-subtitle"
        ),

        # ── KPIs globales ────────────────────────────────────────────────
        dbc.Row([
            dbc.Col(_kpi(
                _fmt_usd(stats.get("total_market_cap", 0)),
                "Capitalización Total", "var(--accent-blue)"
            ), md=3),
            dbc.Col(_kpi(
                f"{stats.get('btc_dominance', 0):.1f}%",
                "Dominancia BTC", "var(--accent-orange)"
            ), md=3),
            dbc.Col(_kpi(
                _fmt_usd(stats.get("total_volume_24h", 0)),
                "Volumen 24h", "var(--accent-teal)"
            ), md=3),
            dbc.Col(_kpi(
                f"{stats.get('avg_change_pct_24h', 0):+.2f}%",
                "Cambio Promedio 24h",
                "var(--accent-green)" if stats.get("avg_change_pct_24h", 0) >= 0 else "var(--accent-red)"
            ), md=3),
        ], className="mb-3"),

        # ── Top 10 por market cap (barras) + treemap ─────────────────────
        dbc.Row([
            dbc.Col([
                html.Div([
                    dcc.Graph(figure=_fig_mcap_bar(df.head(10)),
                              config={"displayModeBar": False})
                ], className="graph-wrapper")
            ], md=7),
            dbc.Col([
                html.Div([
                    dcc.Graph(figure=_fig_dominance_pie(df.head(8)),
                              config={"displayModeBar": False})
                ], className="graph-wrapper")
            ], md=5),
        ], className="mb-3"),

        # ── Tabla de top 20 ──────────────────────────────────────────────
        dbc.Card([
            dbc.CardHeader(f"📋 Top 20 Criptomonedas por Market Cap · {_timestamp()}"),
            dbc.CardBody([_tabla_top(df)])
        ]),

    ], fluid=True, className="py-3")


# ── Helpers ──────────────────────────────────────────────────────────────────

def _kpi(valor, label, color):
    return html.Div([
        html.Div(valor, className="kpi-value", style={"color": color}),
        html.Div(label, className="kpi-label"),
    ], className="kpi-card")


def _fig_mcap_bar(df: pd.DataFrame):
    COLORS = ["#7eb8f7","#c5b8f0","#7ed4c5","#f7c87e","#f7a8c4",
              "#88e0b4","#f7958a","#b8d8f0","#e0c57e","#c8f0b8"]
    fig = px.bar(
        df.sort_values("market_cap"),
        x="market_cap", y="symbol",
        orientation="h",
        color="symbol",
        color_discrete_sequence=COLORS,
        text=df.sort_values("market_cap")["market_cap"].apply(_fmt_usd),
        title="Market Cap Top 10 (USD)",
        labels={"market_cap": "", "symbol": ""},
    )
    fig.update_traces(textposition="outside")
    fig.update_layout(
        paper_bgcolor="#161b22", plot_bgcolor="#161b22",
        font_color="#8b949e", font_family="DM Sans",
        title_font_color="#e6edf3", title_font_size=14,
        showlegend=False,
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, tickfont=dict(color="#e6edf3", size=12)),
        margin=dict(t=45, b=10, l=10, r=80),
    )
    return fig


def _fig_dominance_pie(df: pd.DataFrame):
    COLORS = ["#f7c87e","#7eb8f7","#c5b8f0","#7ed4c5",
              "#f7a8c4","#88e0b4","#f7958a","#8b949e"]
    fig = px.pie(
        df, names="symbol", values="market_cap",
        hole=0.5,
        color_discrete_sequence=COLORS,
        title="Dominancia de mercado"
    )
    fig.update_layout(
        paper_bgcolor="#161b22", plot_bgcolor="#161b22",
        font_color="#8b949e", font_family="DM Sans",
        title_font_color="#e6edf3", title_font_size=14,
        margin=dict(t=45, b=10, l=10, r=10),
        legend=dict(font=dict(color="#8b949e"), orientation="v")
    )
    return fig


def _tabla_top(df: pd.DataFrame):
    filas = []
    for i, (_, r) in enumerate(df.iterrows(), 1):
        chg  = r["change_pct_24h"]
        cls  = "price-up" if chg >= 0 else "price-down"
        signo = "▲" if chg >= 0 else "▼"
        filas.append(html.Tr([
            html.Td(f"#{i}", style={"color": "var(--text-dim)"}),
            html.Td(html.Strong(r["symbol"], style={"color": "var(--accent-blue)"})),
            html.Td(r["name"], style={"color": "var(--text-mid)", "fontSize": "0.82rem"}),
            html.Td(f"${r['price']:,.4f}" if r["price"] < 1 else f"${r['price']:,.2f}",
                    className="mono"),
            html.Td(_fmt_usd(r["market_cap"]),   className="mono"),
            html.Td(_fmt_usd(r["volume_24h"]),   className="mono"),
            html.Td(
                html.Span(f"{signo} {abs(chg):.2f}%", className=cls),
            ),
        ]))

    return html.Table([
        html.Thead(html.Tr([
            html.Th("#"), html.Th("Symbol"), html.Th("Nombre"),
            html.Th("Precio"), html.Th("Market Cap"),
            html.Th("Vol. 24h"), html.Th("Cambio 24h")
        ])),
        html.Tbody(filas)
    ], className="crypto-table")


def _fmt_usd(v: float) -> str:
    if v >= 1e12: return f"${v/1e12:.2f}T"
    if v >= 1e9:  return f"${v/1e9:.2f}B"
    if v >= 1e6:  return f"${v/1e6:.2f}M"
    return f"${v:,.2f}"


def _timestamp() -> str:
    from datetime import datetime
    return datetime.utcnow().strftime("Actualizado %H:%M UTC")

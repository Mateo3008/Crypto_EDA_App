"""
tabs/objetivos.py
Pestaña de Objetivos y Justificación del proyecto crypto.
"""

from dash import html
import dash_bootstrap_components as dbc


def layout():
    return dbc.Container([

        html.H2("🎯 Objetivos del Proyecto", className="section-title"),
        html.P(
            "Propósitos analíticos y técnicos que guían este sistema "
            "de monitoreo y predicción del mercado de criptomonedas.",
            className="section-subtitle"
        ),

        # ── Objetivo general ─────────────────────────────────────────────
        dbc.Card([
            dbc.CardHeader("🏆 Objetivo General"),
            dbc.CardBody([
                html.P(
                    "Desarrollar un dashboard interactivo en tiempo real que integre "
                    "datos de la API CryptoCompare para ofrecer análisis exploratorio, "
                    "visualizaciones de mercado y predicciones de tendencia de precio "
                    "a corto plazo mediante un modelo de clasificación supervisado.",
                    style={"fontSize": "1.05rem", "color": "var(--text-bright)"}
                )
            ])
        ], className="mb-3"),

        # ── Objetivos específicos ────────────────────────────────────────
        dbc.Card([
            dbc.CardHeader("📋 Objetivos Específicos"),
            dbc.CardBody([
                dbc.Row([
                    dbc.Col(_obj("01", "Consumir API en tiempo real",
                                 "Integrar el endpoint /top/mktcapfull de CryptoCompare "
                                 "para obtener precios, market cap y volúmenes actualizados.",
                                 "var(--accent-blue)"), md=6),
                    dbc.Col(_obj("02", "Análisis de series de tiempo",
                                 "Construir gráficos OHLC, velas y líneas de tendencia "
                                 "usando histórico diario de los principales pares.",
                                 "var(--accent-purple)"), md=6),
                ], className="mb-3"),
                dbc.Row([
                    dbc.Col(_obj("03", "Análisis de correlaciones",
                                 "Identificar cómo se correlacionan los precios de las "
                                 "principales criptomonedas en diferentes ventanas temporales.",
                                 "var(--accent-teal)"), md=6),
                    dbc.Col(_obj("04", "Modelo predictivo de señal",
                                 "Entrenar un clasificador para predecir si el precio de "
                                 "una cripto subirá o bajará en la próxima sesión.",
                                 "var(--accent-orange)"), md=6),
                ]),
            ])
        ], className="mb-3"),

        # ── Justificación ────────────────────────────────────────────────
        dbc.Card([
            dbc.CardHeader("💡 Justificación"),
            dbc.CardBody([
                dbc.Row([
                    dbc.Col([
                        html.H6("Económica", className="fw-bold",
                                style={"color": "var(--accent-green)"}),
                        html.P(
                            "El mercado cripto supera $2T en capitalización. "
                            "Herramientas analíticas accesibles democratizan el análisis "
                            "de datos para inversores pequeños.",
                            className="small", style={"color": "var(--text-mid)"}
                        )
                    ], md=4),
                    dbc.Col([
                        html.H6("Técnica", className="fw-bold",
                                style={"color": "var(--accent-blue)"}),
                        html.P(
                            "Demuestra la integración de APIs REST, procesamiento "
                            "de series temporales y ML en una sola aplicación Python "
                            "open-source y reproducible.",
                            className="small", style={"color": "var(--text-mid)"}
                        )
                    ], md=4),
                    dbc.Col([
                        html.H6("Educativa", className="fw-bold",
                                style={"color": "var(--accent-purple)"}),
                        html.P(
                            "Sirve como plantilla de referencia para proyectos "
                            "de análisis financiero con Dash, adaptable a stocks, "
                            "forex o commodities.",
                            className="small", style={"color": "var(--text-mid)"}
                        )
                    ], md=4),
                ])
            ])
        ], className="mb-3"),

        # ── Alcance ──────────────────────────────────────────────────────
        dbc.Card([
            dbc.CardHeader("🔭 Alcance"),
            dbc.CardBody([
                dbc.Row([
                    dbc.Col([
                        html.H6("✅ Incluye", className="fw-bold",
                                style={"color": "var(--accent-green)"}),
                        html.Ul([
                            html.Li("Top 50 criptos por market cap."),
                            html.Li("Histórico de hasta 90 días."),
                            html.Li("Series de tiempo, histogramas, correlación."),
                            html.Li("Predicción de señal alcista/bajista."),
                            html.Li("Actualización automática cada 5 min."),
                        ], style={"color": "var(--text-mid)", "fontSize": "0.88rem"})
                    ], md=6),
                    dbc.Col([
                        html.H6("❌ Fuera del alcance", className="fw-bold",
                                style={"color": "var(--accent-red)"}),
                        html.Ul([
                            html.Li("Ejecución automática de órdenes."),
                            html.Li("Análisis de sentimiento de redes sociales."),
                            html.Li("Backtesting de estrategias completas."),
                            html.Li("Datos de derivados (futuros, opciones)."),
                        ], style={"color": "var(--text-mid)", "fontSize": "0.88rem"})
                    ], md=6),
                ])
            ])
        ]),

    ], fluid=True, className="py-3")


def _obj(num, titulo, desc, color):
    return html.Div([
        html.Span(num, style={
            "fontFamily": "Space Grotesk, sans-serif",
            "fontSize": "1.8rem", "fontWeight": "700",
            "color": color, "display": "block", "marginBottom": "6px"
        }),
        html.Strong(titulo, style={"color": "var(--text-bright)", "fontSize": "0.95rem"}),
        html.P(desc, className="small mb-0 mt-1", style={"color": "var(--text-mid)"})
    ], style={
        "background": "var(--bg-card2)", "borderRadius": "10px",
        "padding": "18px", "marginBottom": "12px",
        "border": "1px solid var(--border)"
    })

"""
tabs/introduccion.py
Pestaña de Introducción: presentación del mercado cripto y del dashboard.
"""

from dash import html
import dash_bootstrap_components as dbc


def layout():
    return dbc.Container([

        # ── Hero ──────────────────────────────────────────────────────────
        html.Div([
            html.Div([
                html.Span("", className="live-dot"),
                "LIVE DATA · CryptoCompare API"
            ], className="live-badge mb-3"),
            html.H1("Crypto Market Dashboard", className="section-title",
                    style={"fontSize": "2.2rem"}),
            html.P(
                "Monitoreo en tiempo real del mercado de criptomonedas. "
                "Precios, capitalización, volumen, correlaciones y predicciones "
                "de tendencia con actualización automática.",
                className="section-subtitle", style={"fontSize": "1rem"}
            ),
            html.Div([
                html.Span("Top 20 Coins",          className="pill pill-blue"),
                html.Span("CryptoCompare API",      className="pill pill-purple"),
                html.Span("Dash Python",            className="pill pill-teal"),
                html.Span("Tiempo Real",            className="pill pill-orange"),

            ])
        ], className="hero-banner"),

        # ── KPIs del proyecto ────────────────────────────────────────────
        dbc.Row([
            dbc.Col(_kpi("20",  "Criptomonedas monitoreadas"), md=3),
            dbc.Col(_kpi("5min","Frecuencia de actualización"), md=3),
            dbc.Col(_kpi("6",   "Indicadores de mercado"),     md=3),
            dbc.Col(_kpi("10",  "Secciones del dashboard"),    md=3),
        ], className="mb-3"),

        # ── Qué es este dashboard ────────────────────────────────────────
        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader("📌 ¿Qué es este Dashboard?"),
                    dbc.CardBody([
                        html.P(
                            "Una aplicación analítica interactiva construida con Python y Dash "
                            "que consume datos en tiempo real de la API de CryptoCompare para "
                            "ofrecer una visión integral del mercado de activos digitales."
                        ),
                        html.P(
                            "Desde la exploración de precios y volúmenes hasta predicciones "
                            "de dirección de precio basadas en indicadores técnicos calculados "
                            "con scikit-learn."
                        ),
                    ])
                ])
            ], md=6),
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader("🔌 Fuente de Datos: CryptoCompare"),
                    dbc.CardBody([
                        html.P("Endpoints utilizados:"),
                        html.Ul([
                            html.Li([html.Code("/data/top/mktcapfull"), " → Top coins por market cap"]),
                            html.Li([html.Code("/data/v2/histoday"),    " → Histórico diario OHLCV"]),
                            html.Li([html.Code("/data/v2/histohour"),   " → Histórico por hora"]),
                        ]),
                        html.P(
                            "Sin API key: límite de ~50 req/hora. "
                            "Con API key gratuita: hasta 100 000 req/mes.",
                            className="text-muted small mb-0"
                        )
                    ])
                ])
            ], md=6),
        ], className="mb-3"),

        # ── Navegación guiada ────────────────────────────────────────────
        dbc.Card([
            dbc.CardHeader("🗺️ Mapa del Dashboard"),
            dbc.CardBody([
                dbc.Row([
                    dbc.Col(_nav_item("📖", "Introducción",  "Descripción del proyecto y fuentes de datos"), md=4),
                    dbc.Col(_nav_item("🌍", "Contexto",      "El mercado cripto global en números"),          md=4),
                    dbc.Col(_nav_item("🔍", "Problema",      "Volatilidad y market cap por categoría"),       md=4),
                ], className="mb-2"),
                dbc.Row([
                    dbc.Col(_nav_item("🎯", "Objetivos",      "Metas y justificación del análisis"),         md=4),
                    dbc.Col(_nav_item("📚", "Marco Teórico",  "Variables y conceptos del mercado cripto"),   md=4),
                    dbc.Col(_nav_item("⚙️", "Metodología",    "Pipeline de datos y modelo"),                 md=4),
                ], className="mb-2"),
                dbc.Row([
                    dbc.Col(_nav_item("📊", "Resultados",    "EDA: series de tiempo, histogramas, correl."), md=4),
                    dbc.Col(_nav_item("✅", "Conclusiones",  "Hallazgos y proyecciones"),                    md=4),
                ]),
            ])
        ]),

    ], fluid=True, className="py-3")


def _kpi(valor, label):
    return html.Div([
        html.Div(valor, className="kpi-value"),
        html.Div(label, className="kpi-label"),
    ], className="kpi-card")


def _nav_item(emoji, titulo, desc):
    return html.Div([
        html.Span(emoji, style={"fontSize": "1.4rem", "marginRight": "8px"}),
        html.Strong(titulo, style={"color": "var(--accent-blue)", "fontSize": "0.9rem"}),
        html.P(desc, className="small mb-0 mt-1", style={"color": "var(--text-mid)"}),
    ], style={
        "background": "var(--bg-card2)", "borderRadius": "10px",
        "padding": "14px", "marginBottom": "10px",
        "border": "1px solid var(--border)"
    })

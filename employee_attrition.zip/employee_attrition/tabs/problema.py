"""
tabs/problema.py
Pestaña del Problema: volatilidad del mercado cripto y distribución de market cap.
"""

import sys, os
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from dash import html, dcc
import dash_bootstrap_components as dbc

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "data"))
from fetch_data import get_top_coins_cached

COLORES = ["#7eb8f7","#c5b8f0","#7ed4c5","#f7c87e","#f7a8c4",
           "#88e0b4","#f7958a","#b8d8f0","#e0c57e","#c8f0b8"]


def layout():
    df = get_top_coins_cached(limit=50)

    return dbc.Container([

        html.H2("🔍 Planteamiento del Problema", className="section-title"),
        html.P(
            "La extrema volatilidad del mercado cripto dificulta la toma de "
            "decisiones de inversión basada en datos.",
            className="section-subtitle"
        ),

        # ── Pregunta de investigación ────────────────────────────────────
        dbc.Card([
            dbc.CardHeader("📝 Pregunta de Investigación"),
            dbc.CardBody([
                html.Blockquote(
                    html.P(
                        "¿Es posible anticipar la dirección de precio a corto plazo de "
                        "las principales criptomonedas utilizando indicadores técnicos "
                        "derivados de datos OHLCV históricos?",
                        style={"fontStyle": "italic", "fontSize": "1.05rem",
                               "color": "var(--accent-blue)"}
                    ),
                    className="border-start border-4 ps-3",
                    style={"borderColor": "#7eb8f7"}
                )
            ])
        ], className="mb-3"),

        # ── Gráficos de volatilidad y distribución ───────────────────────
        dbc.Row([
            dbc.Col([
                html.Div([
                    dcc.Graph(figure=_fig_volatilidad_scatter(df),
                              config={"displayModeBar": False})
                ], className="graph-wrapper")
            ], md=7),
            dbc.Col([
                html.Div([
                    dcc.Graph(figure=_fig_cambio_24h(df),
                              config={"displayModeBar": False})
                ], className="graph-wrapper")
            ], md=5),
        ], className="mb-3"),

        # ── Distribución de market cap por rango ─────────────────────────
        dbc.Row([
            dbc.Col([
                html.Div([
                    dcc.Graph(figure=_fig_mcap_rango(df),
                              config={"displayModeBar": False})
                ], className="graph-wrapper")
            ], md=6),
            dbc.Col([
                html.Div([
                    dcc.Graph(figure=_fig_vol_vs_mcap(df),
                              config={"displayModeBar": False})
                ], className="graph-wrapper")
            ], md=6),
        ], className="mb-3"),

        # ── Contextualización del problema ───────────────────────────────
        dbc.Card([
            dbc.CardHeader("⚠️ Dimensiones del Problema"),
            dbc.CardBody([
                dbc.Row([
                    dbc.Col(_dim("📉", "Alta Volatilidad",
                                 "Cambios de ±20% en 24h son comunes en altcoins, "
                                 "haciendo el análisis manual insuficiente.",
                                 "var(--accent-red)"), md=4),
                    dbc.Col(_dim("📊", "Volumen Asimétrico",
                                 "BTC y ETH concentran >60% del volumen total, "
                                 "generando asimetría en señales técnicas.",
                                 "var(--accent-orange)"), md=4),
                    dbc.Col(_dim("🔄", "Correlación Dinámica",
                                 "Las correlaciones entre monedas cambian según "
                                 "el ciclo de mercado (bull/bear), limitando diversificación.",
                                 "var(--accent-blue)"), md=4),
                ])
            ])
        ]),

    ], fluid=True, className="py-3")


# ── Figuras ──────────────────────────────────────────────────────────────────

def _fig_volatilidad_scatter(df: pd.DataFrame):
    """Scatter: precio vs volatilidad (rango %)"""
    df2 = df.copy()
    df2["rango_pct"] = ((df2["high_24h"] - df2["low_24h"]) / df2["low_24h"].replace(0, np.nan) * 100).fillna(0)
    df2 = df2[df2["price"] > 0].head(30)

    fig = px.scatter(
        df2, x="market_cap", y="rango_pct",
        size="volume_24h", color="change_pct_24h",
        text="symbol",
        color_continuous_scale=["#f7958a", "#8b949e", "#88e0b4"],
        color_continuous_midpoint=0,
        title="Volatilidad 24h vs Market Cap",
        labels={"market_cap": "Market Cap (USD)", "rango_pct": "Rango H-L 24h (%)"},
        log_x=True,
    )
    fig.update_traces(textposition="top center", textfont=dict(size=9, color="#8b949e"))
    _dark_layout(fig, "Volatilidad 24h vs Market Cap")
    fig.update_coloraxes(colorbar=dict(
        tickfont=dict(color="#8b949e"), title=dict(text="%24h", font=dict(color="#8b949e"))
    ))
    return fig


def _fig_cambio_24h(df: pd.DataFrame):
    """Barras: cambio % 24h para las top 15"""
    df2 = df.head(15).copy()
    df2 = df2.sort_values("change_pct_24h")
    df2["color"] = df2["change_pct_24h"].apply(lambda x: "#88e0b4" if x >= 0 else "#f7958a")

    fig = go.Figure(go.Bar(
        x=df2["change_pct_24h"],
        y=df2["symbol"],
        orientation="h",
        marker_color=df2["color"],
        text=df2["change_pct_24h"].apply(lambda x: f"{x:+.2f}%"),
        textposition="outside",
        textfont=dict(size=9),
    ))
    _dark_layout(fig, "Cambio de precio 24h (%)")
    fig.update_layout(
        xaxis=dict(showgrid=False, zeroline=True, zerolinecolor="var(--border)",
                   tickformat="+.1f", ticksuffix="%", tickfont=dict(color="#8b949e")),
        yaxis=dict(showgrid=False, tickfont=dict(color="#e6edf3")),
    )
    return fig


def _fig_mcap_rango(df: pd.DataFrame):
    """Donut: distribución de market cap por rangos"""
    def rango(mc):
        if mc >= 100e9: return "Large Cap (>100B)"
        if mc >= 10e9:  return "Mid Cap (10-100B)"
        if mc >= 1e9:   return "Small Cap (1-10B)"
        return "Micro Cap (<1B)"

    df2 = df.copy()
    df2["rango_mc"] = df2["market_cap"].apply(rango)
    gr = df2.groupby("rango_mc")["market_cap"].sum().reset_index()

    fig = px.pie(gr, names="rango_mc", values="market_cap",
                 hole=0.55,
                 color_discrete_sequence=["#7eb8f7","#c5b8f0","#7ed4c5","#f7c87e"],
                 title="Market Cap por rango de capitalización")
    _dark_layout_pie(fig)
    return fig


def _fig_vol_vs_mcap(df: pd.DataFrame):
    """Scatter: relación volumen/mcap como liquidez relativa"""
    df2 = df.copy()
    df2["liq_ratio"] = (df2["volume_24h"] / df2["market_cap"].replace(0, np.nan) * 100).fillna(0)
    df2 = df2.head(20).sort_values("liq_ratio", ascending=False)

    fig = px.bar(df2, x="symbol", y="liq_ratio",
                 color="liq_ratio",
                 color_continuous_scale=["#1c2230", "#7eb8f7"],
                 title="Ratio Liquidez (Vol/MCap %) — Top 20",
                 labels={"liq_ratio": "Vol/MCap (%)", "symbol": ""},
                 text=df2["liq_ratio"].apply(lambda x: f"{x:.1f}%"))
    fig.update_traces(textposition="outside", textfont=dict(size=9))
    _dark_layout(fig, "Ratio Liquidez (Vol/MCap %) — Top 20")
    fig.update_coloraxes(showscale=False)
    return fig


# ── Layout helpers ────────────────────────────────────────────────────────────

def _dark_layout(fig, title=""):
    fig.update_layout(
        paper_bgcolor="#161b22", plot_bgcolor="#161b22",
        font_color="#8b949e", font_family="DM Sans",
        title=dict(text=title, font=dict(color="#e6edf3", size=13)),
        margin=dict(t=48, b=20, l=20, r=20),
        xaxis=dict(gridcolor="#1c2230", zeroline=False),
        yaxis=dict(gridcolor="#1c2230", zeroline=False),
    )


def _dark_layout_pie(fig):
    fig.update_layout(
        paper_bgcolor="#161b22", plot_bgcolor="#161b22",
        font_color="#8b949e", font_family="DM Sans",
        title_font_color="#e6edf3", title_font_size=13,
        legend=dict(font=dict(color="#8b949e")),
        margin=dict(t=48, b=10, l=10, r=10),
    )


def _dim(emoji, titulo, texto, color):
    return html.Div([
        html.Div([
            html.Span(emoji, style={"fontSize": "1.4rem"}),
            html.Strong(f"  {titulo}", style={"color": color}),
        ], style={"marginBottom": "6px"}),
        html.P(texto, className="small mb-0", style={"color": "var(--text-mid)"})
    ], style={
        "background": "var(--bg-card2)", "borderRadius": "10px",
        "padding": "16px", "border": "1px solid var(--border)"
    })

"""
tabs/prediccion.py
Predicción interactiva: el usuario ingresa datos de una cripto
y el modelo entrenado on-the-fly predice si el precio subirá o bajará.
"""

import sys, os
import numpy as np
import pandas as pd
from dash import html, dcc, callback, Input, Output, State
import dash_bootstrap_components as dbc

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "data"))
from fetch_data import fetch_histoday, get_top_coins_cached

from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

SYMBOLS = ["BTC", "ETH", "BNB", "SOL", "XRP", "ADA", "AVAX", "DOGE", "DOT", "LTC"]


def layout():
    return dbc.Container([

        html.H2("🤖 Predicción de Señal", className="section-title"),
        html.P(
            "Selecciona una criptomoneda para entrenar el modelo con su "
            "histórico y predecir si el precio subirá o bajará en la próxima sesión.",
            className="section-subtitle"
        ),

        dbc.Row([
            # ── Panel izquierdo: selector + formulario ────────────────────
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader("⚙️ Configuración"),
                    dbc.CardBody([

                        html.Label("Criptomoneda", className="fw-bold small",
                                   style={"color": "var(--text-mid)"}),
                        dcc.Dropdown(
                            id="pred-symbol",
                            options=[{"label": s, "value": s} for s in SYMBOLS],
                            value="BTC",
                            clearable=False,
                            style={"background": "#0d1117", "color": "#e6edf3",
                                   "borderRadius": "8px", "border": "1px solid var(--border)"}
                        ),
                        html.Br(),

                        html.Label("Días de histórico para entrenar", className="fw-bold small",
                                   style={"color": "var(--text-mid)"}),
                        dcc.Slider(id="pred-days", min=30, max=90, step=10, value=60,
                                   marks={30: "30d", 60: "60d", 90: "90d"},
                                   tooltip={"placement": "bottom", "always_visible": True}),
                        html.Br(),

                        html.Hr(style={"borderColor": "var(--border)"}),
                        html.H6("Ingresa valores actuales para predecir:",
                                className="mt-2 mb-3",
                                style={"color": "var(--accent-blue)"}),

                        _slider_campo("pred-open",   "Precio Open (USD)",   1,    100000, 45000),
                        _slider_campo("pred-high",   "Precio High (USD)",   1,    110000, 47000),
                        _slider_campo("pred-low",    "Precio Low (USD)",    1,    100000, 43000),
                        _slider_campo("pred-close",  "Precio Close (USD)",  1,    110000, 46000),
                        _slider_campo("pred-volume", "Volumen (M USD)",     100,  80000,  25000),

                        html.Div([
                            html.Button(
                                "🔮 Predecir señal",
                                id="btn-predecir-crypto",
                                className="btn-predict mt-3",
                                n_clicks=0
                            )
                        ], style={"textAlign": "center"})
                    ])
                ])
            ], md=5),

            # ── Panel derecho: resultado ──────────────────────────────────
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader("📊 Resultado"),
                    dbc.CardBody([
                        html.Div(id="resultado-crypto", children=[
                            html.Div([
                                html.Div("🤔", style={"fontSize": "3.5rem",
                                                     "textAlign": "center"}),
                                html.P(
                                    "Configura los parámetros y presiona Predecir.",
                                    className="text-center mt-2",
                                    style={"color": "var(--text-mid)"}
                                )
                            ])
                        ])
                    ])
                ]),

                # Indicadores rápidos del snapshot actual
                dbc.Card([
                    dbc.CardHeader("📡 Datos en vivo del símbolo seleccionado"),
                    dbc.CardBody([
                        html.Div(id="live-snap")
                    ])
                ], className="mt-3"),

                # Guía de interpretación
                dbc.Card([
                    dbc.CardHeader("ℹ️ Interpretación"),
                    dbc.CardBody([
                        html.P([html.Strong("🟢 ALCISTA: "),
                                "El modelo predice que close > open en la próxima sesión."],
                               className="small", style={"color": "var(--text-mid)"}),
                        html.P([html.Strong("🔴 BAJISTA: "),
                                "El modelo predice que close ≤ open en la próxima sesión."],
                               className="small", style={"color": "var(--text-mid)"}),
                        html.P(
                            "⚠️ Este modelo es demostrativo. No constituye asesoría de inversión.",
                            className="small", style={"color": "var(--text-dim)"}
                        )
                    ])
                ], className="mt-3"),

            ], md=7),
        ]),

    ], fluid=True, className="py-3")


# ── Callbacks ────────────────────────────────────────────────────────────────

@callback(
    Output("resultado-crypto", "children"),
    Output("live-snap",         "children"),
    Input("btn-predecir-crypto", "n_clicks"),
    State("pred-symbol",  "value"),
    State("pred-days",    "value"),
    State("pred-open",    "value"),
    State("pred-high",    "value"),
    State("pred-low",     "value"),
    State("pred-close",   "value"),
    State("pred-volume",  "value"),
    prevent_initial_call=True,
)
def predecir_cripto(n_clicks, symbol, days, open_, high, low, close, volume):
    """Entrena el modelo con el histórico del símbolo y devuelve la predicción."""

    # ── Snapshot en vivo ──────────────────────────────────────────────
    df_snap = get_top_coins_cached(50)
    row     = df_snap[df_snap["symbol"] == symbol]
    snap_html = _snapshot_card(row.iloc[0] if not row.empty else None)

    # ── Entrenar modelo ───────────────────────────────────────────────
    df_hist = fetch_histoday(symbol, days=days)
    model   = _train(df_hist)

    if model is None:
        return dbc.Alert("⚠️ Datos insuficientes para entrenar.", color="warning"), snap_html

    # ── Features de entrada ───────────────────────────────────────────
    vol_usd = volume * 1e6  # convertir M USD a USD

    # Calcular features derivadas como en el entrenamiento
    hl_pct  = ((high - low) / low * 100) if low > 0 else 0
    retorno = ((close - open_) / open_ * 100) if open_ > 0 else 0

    # sma7 y sma30 del histórico reciente
    sma7  = df_hist["close"].tail(7).mean()
    sma30 = df_hist["close"].tail(30).mean()
    vol_rel = vol_usd / df_hist["volume"].tail(7).mean() if df_hist["volume"].tail(7).mean() > 0 else 1

    entrada = pd.DataFrame([{
        "hl_pct" : hl_pct,
        "sma7"   : sma7,
        "sma30"  : sma30,
        "retorno": retorno,
        "vol_rel": vol_rel,
        "open"   : open_,
        "high"   : high,
        "low"    : low,
        "close"  : close,
        "volume" : vol_usd,
    }])

    try:
        prob = model.predict_proba(entrada)[0][1]
    except Exception:
        prob = 0.5

    pred = 1 if prob >= 0.5 else 0

    resultado_html = _resultado_card(symbol, pred, prob)
    return resultado_html, snap_html


# ── Helpers de UI ─────────────────────────────────────────────────────────────

def _train(df: pd.DataFrame):
    """Entrena RandomForest con los datos históricos."""
    try:
        df2 = df.copy()
        df2["hl_pct"]  = (df2["high"] - df2["low"]) / df2["low"].replace(0, np.nan) * 100
        df2["sma7"]    = df2["close"].rolling(7).mean()
        df2["sma30"]   = df2["close"].rolling(30).mean()
        df2["retorno"] = df2["close"].pct_change() * 100
        df2["vol_rel"] = df2["volume"] / df2["volume"].rolling(7).mean()
        df2["señal"]   = (df2["close"] > df2["open"]).astype(int)
        df2 = df2.dropna()

        if len(df2) < 20:
            return None

        FEAT = ["hl_pct", "sma7", "sma30", "retorno", "vol_rel",
                "open", "high", "low", "close", "volume"]
        X, y = df2[FEAT], df2["señal"]
        X_tr, _, y_tr, _ = train_test_split(X, y, test_size=0.2,
                                             random_state=42, stratify=y)
        pipe = Pipeline([
            ("sc",  StandardScaler()),
            ("clf", RandomForestClassifier(n_estimators=100, max_depth=5, random_state=42))
        ])
        pipe.fit(X_tr, y_tr)
        return pipe
    except Exception:
        return None


def _resultado_card(symbol, pred, prob):
    if pred == 1:
        cls   = "bullish"
        emoji = "🟢"
        titulo = f"{symbol} — Señal ALCISTA"
        msg    = f"El modelo estima {prob:.1%} de probabilidad de que el precio suba."
    else:
        cls   = "bearish"
        emoji = "🔴"
        titulo = f"{symbol} — Señal BAJISTA"
        msg    = f"El modelo estima {1-prob:.1%} de probabilidad de que el precio baje."

    barra_pct = prob * 100

    return html.Div([
        html.Div([
            html.Div(emoji, style={"fontSize": "3rem"}),
            html.H5(titulo, className="mt-2"),
            html.P(msg, style={"fontSize": "0.9rem"}),
            # Barra de confianza
            html.Div(style={"height": "10px", "borderRadius": "50px",
                             "background": f"linear-gradient(90deg, "
                             f"{'#88e0b4' if pred else '#f7958a'} {barra_pct:.0f}%, "
                             f"#1c2230 {barra_pct:.0f}%)",
                             "margin": "10px 0"}),
            html.Small(f"Confianza: {max(prob, 1-prob):.1%}",
                       style={"color": "var(--text-mid)"}),
        ], className=f"result-box {cls}")
    ])


def _snapshot_card(row):
    if row is None:
        return html.P("No disponible", style={"color": "var(--text-mid)"})
    chg  = row["change_pct_24h"]
    cls  = "price-up" if chg >= 0 else "price-down"
    return html.Div([
        dbc.Row([
            dbc.Col([html.Span("Precio", className="kpi-label"),
                     html.Div(f"${row['price']:,.2f}", className="kpi-value",
                              style={"fontSize": "1.4rem"})]),
            dbc.Col([html.Span("Cambio 24h", className="kpi-label"),
                     html.Div(f"{chg:+.2f}%", className=f"kpi-value {cls}",
                              style={"fontSize": "1.4rem"})]),
            dbc.Col([html.Span("Vol. 24h", className="kpi-label"),
                     html.Div(_fmt(row["volume_24h"]), className="kpi-value",
                              style={"fontSize": "1.4rem"})]),
        ])
    ])


def _fmt(v):
    if v >= 1e9: return f"${v/1e9:.1f}B"
    if v >= 1e6: return f"${v/1e6:.1f}M"
    return f"${v:,.0f}"


def _slider_campo(id_, label, min_, max_, val):
    return html.Div([
        html.Div([
            html.Label(label, className="small fw-bold",
                       style={"color": "var(--text-mid)"}),
        ], className="mb-1"),
        dcc.Slider(
            id=id_, min=min_, max=max_, value=val,
            step=(max_ - min_) // 100,
            marks={min_: str(min_), max_: str(max_)},
            tooltip={"placement": "bottom", "always_visible": True},
        )
    ], className="mb-3")

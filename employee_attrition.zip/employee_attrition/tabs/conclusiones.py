"""
tabs/conclusiones.py
Conclusiones del proyecto Crypto Dashboard.
"""

from dash import html
import dash_bootstrap_components as dbc


def layout():
    return dbc.Container([

        html.H2("✅ Conclusiones", className="section-title"),
        html.P(
            "Hallazgos principales, aportes del proyecto y proyecciones futuras.",
            className="section-subtitle"
        ),

        dbc.Card([
            dbc.CardHeader("🏆 Conclusiones Principales"),
            dbc.CardBody([
                dbc.Row([
                    dbc.Col(_concl("01",
                        "BTC domina el mercado",
                        "Bitcoin mantiene >40% de dominancia estructural. "
                        "Sus movimientos marcan la tendencia del mercado global.",
                        "var(--accent-orange)"), md=6),
                    dbc.Col(_concl("02",
                        "Alta correlación en bear markets",
                        "Durante caídas, las correlaciones entre cripto se acercan a 1.0, "
                        "limitando la diversificación real de portafolios.",
                        "var(--accent-red)"), md=6),
                ], className="mb-3"),
                dbc.Row([
                    dbc.Col(_concl("03",
                        "El volumen precede al precio",
                        "Picos de volumen consistentemente anteceden movimientos "
                        "significativos de precio, validando su uso como feature.",
                        "var(--accent-teal)"), md=6),
                    dbc.Col(_concl("04",
                        "Random Forest como baseline viable",
                        "El modelo alcanza AUC > 0.58 con solo indicadores técnicos básicos, "
                        "superando el azar y confirmando señal en los datos OHLCV.",
                        "var(--accent-blue)"), md=6),
                ]),
            ])
        ], className="mb-3"),

        dbc.Card([
            dbc.CardHeader("💡 Aporte del Proyecto"),
            dbc.CardBody([
                html.P(
                    "Este dashboard demuestra cómo integrar una API financiera en tiempo real "
                    "con un pipeline analítico completo en Python, desde la ingesta de datos "
                    "hasta la predicción interactiva, usando exclusivamente herramientas open-source.",
                    style={"color": "var(--text-bright)"}
                ),
                html.P(
                    "La arquitectura modular permite sustituir la fuente de datos (CoinGecko, "
                    "Binance API, CoinMarketCap) o el modelo (LSTM, XGBoost) sin reescribir "
                    "la estructura del dashboard.",
                    className="mb-0", style={"color": "var(--text-mid)"}
                )
            ])
        ], className="mb-3"),

    ])


def _concl(num, titulo, desc, color):
    return html.Div([
        html.Span(num, style={
            "fontFamily": "Space Grotesk, sans-serif",
            "fontSize": "1.8rem", "fontWeight": "700",
            "color": color, "display": "block", "marginBottom": "6px"
        }),
        html.Strong(titulo, style={"color": "var(--text-bright)"}),
        html.P(desc, className="small mb-0 mt-1", style={"color": "var(--text-mid)"})
    ], style={
        "background": "var(--bg-card2)", "borderRadius": "10px",
        "padding": "18px", "marginBottom": "12px",
        "border": "1px solid var(--border)"
    })

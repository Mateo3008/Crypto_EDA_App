"""
tabs/limitaciones.py
Limitaciones del proyecto Crypto Dashboard.
"""

from dash import html
import dash_bootstrap_components as dbc


def layout():
    return dbc.Container([

        html.H2("⚠️ Limitaciones", className="section-title"),
        html.P(
            "Restricciones técnicas, de datos y de modelado que deben "
            "considerarse al interpretar los resultados.",
            className="section-subtitle"
        ),

        dbc.Row([
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader("📡 Limitaciones de la API"),
                    dbc.CardBody([
                        _lim("🔑", "Rate limits sin API key",
                             "Sin API key: ~50 req/hora. El dashboard usa caché "
                             "de 5 min y fallback sintético para mitigarlo."),
                        _lim("📶", "Latencia y disponibilidad",
                             "CryptoCompare puede tener cortes. El sistema de "
                             "fallback garantiza operabilidad continua."),
                        _lim("🕐", "Granularidad mínima",
                             "El endpoint histoday provee datos diarios. "
                             "Para intraday se requiere histohour o histominute "
                             "con límites de puntos más restrictivos."),
                    ])
                ])
            ], md=6),

            dbc.Col([
                dbc.Card([
                    dbc.CardHeader("🧠 Limitaciones del Modelo"),
                    dbc.CardBody([
                        _lim("📐", "No captura factores externos",
                             "El modelo no incluye sentimiento, noticias, "
                             "regulaciones ni macroeconomía, que dominan el cripto."),
                        _lim("📉", "Target simplificado",
                             "Predecir close > open es una simplificación. "
                             "No cuantifica la magnitud del movimiento."),
                        _lim("🔁", "Sin walk-forward validation",
                             "Se usa hold-out simple. En series temporales "
                             "la validación walk-forward es más apropiada."),
                    ])
                ])
            ], md=6),
        ], className="mb-3"),

        dbc.Card([
            dbc.CardHeader("💻 Otras Limitaciones"),
            dbc.CardBody([
                dbc.Row([
                    dbc.Col(_lim("🔒", "Sin autenticación",
                                 "El dashboard no tiene control de acceso. "
                                 "No apto para producción con datos sensibles sin añadir auth."), md=6),
                    dbc.Col(_lim("📱", "Sin app móvil nativa",
                                 "Es responsive pero no está optimizado para touch ni "
                                 "disponible como PWA/app instalable."), md=6),
                ])
            ])
        ]),

    ], fluid=True, className="py-3")


def _lim(emoji, titulo, texto):
    return html.Div([
        html.Div([
            html.Span(emoji, style={"fontSize": "1.3rem", "marginRight": "10px"}),
            html.Strong(titulo, style={"color": "var(--text-bright)", "fontSize": "0.9rem"}),
        ], style={"display": "flex", "alignItems": "center", "marginBottom": "6px"}),
        html.P(texto, className="small mb-0", style={"color": "var(--text-mid)"})
    ], style={
        "background": "var(--bg-deep)", "borderRadius": "8px",
        "padding": "14px", "marginBottom": "10px",
        "border": "1px solid var(--border)"
    })

"""
tabs/resultados.py  — v2
Pestaña de Resultados con análisis ampliado:
  SECCIÓN 1 — Series de tiempo
    • Velas OHLC con SMA7/SMA30 (selector de moneda)
    • Líneas de precio comparativas: BTC, ETH, SOL, BNB
    • Retornos acumulados normalizados (base 100)

  SECCIÓN 2 — Distribuciones
    • Histograma de cambio % 24h de TODAS las monedas
    • Boxplot de cambio % por grupo de market cap
    • Heatmap ganadores / perdedores (top 30)

  SECCIÓN 3 — Correlaciones
    • Heatmap de correlación de precios (10 monedas, 60 días)
    • Scatter matrix de retornos (BTC, ETH, SOL, BNB, XRP)

  SECCIÓN 4 — Métricas de mercado
    • Barras de volumen 24h top 20
    • Ratio liquidez (Vol/MCap) top 20
    • Bubble chart: MCap vs Precio vs Vol
"""

import sys, os
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from dash import html, dcc
import dash_bootstrap_components as dbc

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "data"))
from fetch_data import (
    fetch_histoday, fetch_multi_histoday,
    get_top_coins_cached
)

# ── Constantes ────────────────────────────────────────────────────────────────
PASTEL = ["#7eb8f7","#c5b8f0","#7ed4c5","#f7c87e","#f7a8c4",
          "#88e0b4","#f7958a","#b8d8f0","#a8d8f0","#e0c57e",
          "#c8f0b8","#f0d8b8","#d8b8f0","#b8f0d8","#f0b8c8"]

CORR_SYMBOLS  = ["BTC","ETH","BNB","SOL","XRP","ADA","AVAX","DOGE","LTC","LINK"]
MULTI_SYMBOLS = ["BTC","ETH","SOL","BNB"]


def layout():
    df_snap  = get_top_coins_cached(limit=30)
    df_btc   = fetch_histoday("BTC", days=90)
    df_corr  = fetch_multi_histoday(CORR_SYMBOLS, days=60)
    df_multi = fetch_multi_histoday(MULTI_SYMBOLS, days=90)

    return dbc.Container([

        html.H2("📊 Resultados", className="section-title"),
        html.P("Análisis exploratorio completo del mercado de criptomonedas.",
               className="section-subtitle"),

        # ══════════════════════════════════════════
        # § 1 — SERIES DE TIEMPO
        # ══════════════════════════════════════════
        _seccion("📈 Series de Tiempo"),

        # Velas BTC
        dbc.Row([
            dbc.Col([
                html.Div([
                    dcc.Graph(figure=_fig_candlestick(df_btc),
                              config={"displayModeBar": True,
                                      "modeBarButtonsToRemove": ["lasso2d","select2d"]})
                ], className="graph-wrapper")
            ], md=12),
        ], className="mb-3"),

        # Comparativa multi-moneda + Retornos acumulados
        dbc.Row([
            dbc.Col([
                html.Div([
                    dcc.Graph(figure=_fig_multi_precio(df_multi),
                              config={"displayModeBar": False})
                ], className="graph-wrapper")
            ], md=6),
            dbc.Col([
                html.Div([
                    dcc.Graph(figure=_fig_retornos_acumulados(df_multi),
                              config={"displayModeBar": False})
                ], className="graph-wrapper")
            ], md=6),
        ], className="mb-4"),

        # ══════════════════════════════════════════
        # § 2 — DISTRIBUCIONES (todas las monedas)
        # ══════════════════════════════════════════
        _seccion("📉 Distribuciones — Top 30 Monedas"),

        dbc.Row([
            dbc.Col([
                html.Div([
                    dcc.Graph(figure=_fig_cambio_hist(df_snap),
                              config={"displayModeBar": False})
                ], className="graph-wrapper")
            ], md=6),
            dbc.Col([
                html.Div([
                    dcc.Graph(figure=_fig_cambio_barras(df_snap),
                              config={"displayModeBar": False})
                ], className="graph-wrapper")
            ], md=6),
        ], className="mb-3"),

        dbc.Row([
            dbc.Col([
                html.Div([
                    dcc.Graph(figure=_fig_heatmap_ganancias(df_snap),
                              config={"displayModeBar": False})
                ], className="graph-wrapper")
            ], md=7),
            dbc.Col([
                html.Div([
                    dcc.Graph(figure=_fig_boxplot_mcap(df_snap),
                              config={"displayModeBar": False})
                ], className="graph-wrapper")
            ], md=5),
        ], className="mb-4"),

        # ══════════════════════════════════════════
        # § 3 — CORRELACIONES
        # ══════════════════════════════════════════
        _seccion("🔗 Análisis de Correlaciones"),

        dbc.Row([
            dbc.Col([
                html.Div([
                    dcc.Graph(figure=_fig_correlacion(df_corr),
                              config={"displayModeBar": False})
                ], className="graph-wrapper")
            ], md=7),
            dbc.Col([
                html.Div([
                    dcc.Graph(figure=_fig_retornos_scatter(df_multi),
                              config={"displayModeBar": False})
                ], className="graph-wrapper")
            ], md=5),
        ], className="mb-4"),

        # ══════════════════════════════════════════
        # § 4 — MÉTRICAS DE MERCADO
        # ══════════════════════════════════════════
        _seccion("💹 Métricas de Mercado"),

        dbc.Row([
            dbc.Col([
                html.Div([
                    dcc.Graph(figure=_fig_volumen_barras(df_snap),
                              config={"displayModeBar": False})
                ], className="graph-wrapper")
            ], md=6),
            dbc.Col([
                html.Div([
                    dcc.Graph(figure=_fig_liquidez(df_snap),
                              config={"displayModeBar": False})
                ], className="graph-wrapper")
            ], md=6),
        ], className="mb-3"),

        dbc.Row([
            dbc.Col([
                html.Div([
                    dcc.Graph(figure=_fig_bubble(df_snap),
                              config={"displayModeBar": False})
                ], className="graph-wrapper")
            ], md=12),
        ]),

    ], fluid=True, className="py-3")


# ══════════════════════════════════════════════════════════
# FIGURA HELPERS
# ══════════════════════════════════════════════════════════

def _dl(fig, title="", height=360):
    """Aplica tema oscuro a cualquier figura."""
    fig.update_layout(
        paper_bgcolor="#161b22", plot_bgcolor="#161b22",
        font_color="#8b949e", font_family="DM Sans",
        title=dict(text=title, font=dict(color="#e6edf3", size=13)),
        margin=dict(t=48, b=24, l=24, r=16),
        xaxis=dict(gridcolor="#1c2230", zeroline=False,
                   tickfont=dict(color="#8b949e")),
        yaxis=dict(gridcolor="#1c2230", zeroline=False,
                   tickfont=dict(color="#8b949e")),
        height=height,
        legend=dict(font=dict(color="#8b949e"), bgcolor="rgba(0,0,0,0)"),
    )
    return fig


# ── § 1 Figuras ───────────────────────────────────────────────────────────────

def _fig_candlestick(df: pd.DataFrame):
    df = df.copy()
    df["sma7"]  = df["close"].rolling(7).mean()
    df["sma30"] = df["close"].rolling(30).mean()

    fig = go.Figure()
    fig.add_trace(go.Candlestick(
        x=df["date"], open=df["open"], high=df["high"],
        low=df["low"], close=df["close"],
        increasing_line_color="#88e0b4",
        decreasing_line_color="#f7958a",
        name="BTC/USD",
    ))
    fig.add_trace(go.Scatter(
        x=df["date"], y=df["sma7"],
        line=dict(color="#7eb8f7", width=1.5, dash="dot"), name="SMA 7"
    ))
    fig.add_trace(go.Scatter(
        x=df["date"], y=df["sma30"],
        line=dict(color="#c5b8f0", width=1.5, dash="dot"), name="SMA 30"
    ))
    _dl(fig, "BTC/USD — Velas OHLC + SMA 7/30 (90 días)", height=400)
    fig.update_layout(
        xaxis=dict(rangeslider=dict(visible=False), gridcolor="#1c2230",
                   tickfont=dict(color="#8b949e")),
        yaxis=dict(tickprefix="$", tickformat=",", gridcolor="#1c2230",
                   tickfont=dict(color="#8b949e")),
    )
    return fig


def _fig_multi_precio(df_wide: pd.DataFrame):
    """Líneas de precio comparativas para BTC, ETH, SOL, BNB."""
    fig = go.Figure()
    cols   = [c for c in df_wide.columns if c != "date"]
    colors = ["#f7c87e", "#7eb8f7", "#88e0b4", "#c5b8f0"]
    for i, sym in enumerate(cols):
        fig.add_trace(go.Scatter(
            x=df_wide["date"], y=df_wide[sym],
            mode="lines", name=sym,
            line=dict(color=colors[i % len(colors)], width=2),
            yaxis=f"y{i+1}" if i > 0 else "y",
        ))
    # Multi-eje Y para poder comparar precios en diferentes escalas
    yaxis_args = dict(
        title="BTC (USD)", gridcolor="#1c2230",
        tickfont=dict(color="#8b949e"), titlefont=dict(color="#f7c87e")
    )
    _dl(fig, "Precio comparativo: BTC, ETH, SOL, BNB (90d)", height=360)
    fig.update_layout(
        yaxis=dict(gridcolor="#1c2230", tickfont=dict(color="#8b949e")),
        hovermode="x unified",
    )
    return fig


def _fig_retornos_acumulados(df_wide: pd.DataFrame):
    """Retorno acumulado normalizado a base 100."""
    fig = go.Figure()
    cols   = [c for c in df_wide.columns if c != "date"]
    colors = ["#f7c87e", "#7eb8f7", "#88e0b4", "#c5b8f0"]
    for i, sym in enumerate(cols):
        serie = df_wide[sym].dropna()
        if serie.empty or serie.iloc[0] == 0:
            continue
        norm = serie / serie.iloc[0] * 100
        fig.add_trace(go.Scatter(
            x=df_wide["date"].iloc[:len(norm)], y=norm,
            mode="lines", name=sym,
            line=dict(color=colors[i % len(colors)], width=2),
        ))
    fig.add_hline(y=100, line_dash="dash", line_color="#484f58", line_width=1)
    _dl(fig, "Retorno acumulado (base 100)", height=360)
    fig.update_layout(hovermode="x unified",
                      yaxis=dict(ticksuffix="%", gridcolor="#1c2230",
                                 tickfont=dict(color="#8b949e")))
    return fig


# ── § 2 Figuras ───────────────────────────────────────────────────────────────

def _fig_cambio_hist(df: pd.DataFrame):
    """Histograma de cambio % 24h para todas las monedas."""
    fig = px.histogram(
        df, x="change_pct_24h", nbins=30,
        color_discrete_sequence=["#7eb8f7"],
        labels={"change_pct_24h": "Cambio 24h (%)"},
    )
    fig.add_vline(x=0, line_dash="dash", line_color="#f7958a", line_width=1)
    _dl(fig, "Distribución de cambio % 24h — Top 30", height=320)
    fig.update_layout(showlegend=False, bargap=0.06)
    return fig


def _fig_cambio_barras(df: pd.DataFrame):
    """Barras horizontales de cambio % 24h, ordenadas."""
    df2 = df.sort_values("change_pct_24h").copy()
    df2["color"] = df2["change_pct_24h"].apply(
        lambda x: "#88e0b4" if x >= 0 else "#f7958a"
    )
    fig = go.Figure(go.Bar(
        x=df2["change_pct_24h"], y=df2["symbol"],
        orientation="h",
        marker_color=df2["color"],
        text=df2["change_pct_24h"].apply(lambda x: f"{x:+.2f}%"),
        textposition="outside",
        textfont=dict(size=8, color="#8b949e"),
    ))
    _dl(fig, "Cambio de precio 24h — Top 30", height=640)
    fig.update_layout(
        xaxis=dict(ticksuffix="%", gridcolor="#1c2230",
                   tickfont=dict(color="#8b949e"), zeroline=True,
                   zerolinecolor="#484f58"),
        yaxis=dict(tickfont=dict(color="#e6edf3", size=10), gridcolor="#1c2230"),
    )
    return fig


def _fig_heatmap_ganancias(df: pd.DataFrame):
    """
    Heatmap 5×6 de cambio % 24h para el top 30.
    Cada celda = una moneda, color = ganancia/pérdida.
    """
    df2    = df.head(30).copy()
    n_cols = 6
    n_rows = int(np.ceil(len(df2) / n_cols))
    # Rellenar hasta completar la grilla
    while len(df2) < n_rows * n_cols:
        df2 = pd.concat([df2, pd.DataFrame([{
            "symbol": "", "change_pct_24h": np.nan
        }])], ignore_index=True)

    z      = df2["change_pct_24h"].values.reshape(n_rows, n_cols)
    text   = df2["symbol"].values.reshape(n_rows, n_cols)
    chg    = df2["change_pct_24h"].values.reshape(n_rows, n_cols)
    custom = [[f"{text[r][c]}<br>{chg[r][c]:+.2f}%"
               if text[r][c] else ""
               for c in range(n_cols)] for r in range(n_rows)]

    fig = go.Figure(go.Heatmap(
        z=z, text=text,
        customdata=custom,
        hovertemplate="%{customdata}<extra></extra>",
        texttemplate="%{text}",
        textfont=dict(size=10, color="white"),
        colorscale=[
            [0.0,  "#c0392b"],
            [0.4,  "#e74c3c"],
            [0.49, "#922b21"],
            [0.5,  "#1c2230"],
            [0.51, "#1a5276"],
            [0.6,  "#1abc9c"],
            [1.0,  "#27ae60"],
        ],
        zmid=0,
        showscale=True,
        colorbar=dict(
            tickfont=dict(color="#8b949e"),
            title=dict(text="%", font=dict(color="#8b949e")),
        ),
    ))
    _dl(fig, "Mapa de calor: Cambio 24h — Top 30", height=360)
    fig.update_layout(
        xaxis=dict(showticklabels=False, showgrid=False),
        yaxis=dict(showticklabels=False, showgrid=False),
    )
    return fig


def _fig_boxplot_mcap(df: pd.DataFrame):
    """Boxplot de cambio % agrupado por rango de market cap."""
    def rango(mc):
        if mc >= 100e9: return "Large\n(>100B)"
        if mc >= 10e9:  return "Mid\n(10-100B)"
        if mc >= 1e9:   return "Small\n(1-10B)"
        return "Micro\n(<1B)"
    df2 = df.copy()
    df2["rango"] = df2["market_cap"].apply(rango)
    fig = px.box(
        df2, x="rango", y="change_pct_24h",
        color="rango",
        color_discrete_sequence=["#7eb8f7","#c5b8f0","#7ed4c5","#f7c87e"],
        labels={"change_pct_24h": "Cambio 24h (%)", "rango": ""},
    )
    _dl(fig, "Cambio % 24h por rango de Market Cap", height=320)
    fig.update_layout(showlegend=False,
                      yaxis=dict(ticksuffix="%", gridcolor="#1c2230",
                                 tickfont=dict(color="#8b949e")))
    return fig


# ── § 3 Figuras ───────────────────────────────────────────────────────────────

def _fig_correlacion(df_wide: pd.DataFrame):
    """Heatmap de correlación de precios entre 10 monedas."""
    if df_wide.empty or len(df_wide.columns) < 3:
        return _empty_fig("Sin datos de correlación")

    numeric = df_wide.drop(columns=["date"], errors="ignore")
    if numeric.shape[0] < 5:
        return _empty_fig("Datos insuficientes para correlación")

    corr = numeric.corr().round(2)

    fig = px.imshow(
        corr,
        text_auto=True,
        color_continuous_scale=[
            [0.0, "#c0392b"], [0.5, "#1c2230"], [1.0, "#27ae60"]
        ],
        zmin=-1, zmax=1,
    )
    fig.update_traces(textfont=dict(size=10, color="white"))
    _dl(fig, f"Correlación de precios: {', '.join(numeric.columns.tolist())}", height=420)
    fig.update_layout(
        xaxis=dict(tickfont=dict(color="#e6edf3", size=10), showgrid=False),
        yaxis=dict(tickfont=dict(color="#e6edf3", size=10), showgrid=False),
        coloraxis_colorbar=dict(
            tickfont=dict(color="#8b949e"),
            title=dict(text="r", font=dict(color="#8b949e")),
        ),
    )
    return fig


def _fig_retornos_scatter(df_wide: pd.DataFrame):
    """Scatter BTC vs ETH de retornos diarios."""
    if df_wide.empty:
        return _empty_fig("Sin datos")
    cols = [c for c in df_wide.columns if c != "date"]
    if len(cols) < 2:
        return _empty_fig("Necesita 2+ monedas")
    c1, c2 = cols[0], cols[1]
    r1 = df_wide[c1].pct_change().dropna() * 100
    r2 = df_wide[c2].pct_change().dropna() * 100
    n  = min(len(r1), len(r2))
    fig = go.Figure(go.Scatter(
        x=r1.values[:n], y=r2.values[:n],
        mode="markers",
        marker=dict(color="#7eb8f7", size=5, opacity=0.7),
        name=f"{c1} vs {c2}",
    ))
    # Línea de regresión
    if n > 3:
        m, b = np.polyfit(r1.values[:n], r2.values[:n], 1)
        x_lr = np.linspace(r1.min(), r1.max(), 50)
        fig.add_trace(go.Scatter(
            x=x_lr, y=m * x_lr + b,
            mode="lines",
            line=dict(color="#f7c87e", width=2, dash="dot"),
            name="Regresión"
        ))
    _dl(fig, f"Retornos diarios: {c1} vs {c2}", height=360)
    fig.update_layout(
        xaxis=dict(title=f"Retorno {c1} (%)", ticksuffix="%",
                   gridcolor="#1c2230", tickfont=dict(color="#8b949e")),
        yaxis=dict(title=f"Retorno {c2} (%)", ticksuffix="%",
                   gridcolor="#1c2230", tickfont=dict(color="#8b949e")),
    )
    return fig


# ── § 4 Figuras ───────────────────────────────────────────────────────────────

def _fig_volumen_barras(df: pd.DataFrame):
    """Barras de volumen 24h top 20, ordenadas."""
    df2 = df.nlargest(20, "volume_24h").sort_values("volume_24h")
    fig = px.bar(
        df2, x="volume_24h", y="symbol", orientation="h",
        color="change_pct_24h",
        color_continuous_scale=["#f7958a", "#1c2230", "#88e0b4"],
        color_continuous_midpoint=0,
        text=df2["volume_24h"].apply(_fmt_usd),
        labels={"volume_24h": "Volumen 24h (USD)", "symbol": ""},
    )
    fig.update_traces(textposition="outside", textfont=dict(size=8))
    _dl(fig, "Volumen 24h — Top 20", height=460)
    fig.update_layout(
        xaxis=dict(showticklabels=False, gridcolor="#1c2230"),
        yaxis=dict(tickfont=dict(color="#e6edf3", size=10)),
        coloraxis_colorbar=dict(
            title=dict(text="%24h", font=dict(color="#8b949e")),
            tickfont=dict(color="#8b949e"),
        ),
    )
    return fig


def _fig_liquidez(df: pd.DataFrame):
    """Ratio de liquidez (Vol/MCap %) top 20."""
    df2 = df.copy()
    df2["liq"] = (df2["volume_24h"] / df2["market_cap"].replace(0, np.nan) * 100).fillna(0)
    df2 = df2.nlargest(20, "liq").sort_values("liq")
    fig = px.bar(
        df2, x="liq", y="symbol", orientation="h",
        color="liq",
        color_continuous_scale=["#1c2230", "#7eb8f7"],
        text=df2["liq"].apply(lambda x: f"{x:.1f}%"),
        labels={"liq": "Vol/MCap (%)", "symbol": ""},
    )
    fig.update_traces(textposition="outside", textfont=dict(size=8))
    _dl(fig, "Ratio Liquidez (Vol/MCap %) — Top 20", height=460)
    fig.update_layout(
        xaxis=dict(ticksuffix="%", gridcolor="#1c2230"),
        yaxis=dict(tickfont=dict(color="#e6edf3", size=10)),
        coloraxis_showscale=False,
    )
    return fig


def _fig_bubble(df: pd.DataFrame):
    """Bubble chart: Market Cap (x) vs Cambio % 24h (y), tamaño = Volumen."""
    df2 = df[df["market_cap"] > 0].copy()
    df2["chg_abs"] = df2["change_pct_24h"].abs()
    fig = px.scatter(
        df2,
        x="market_cap",
        y="change_pct_24h",
        size="volume_24h",
        color="change_pct_24h",
        text="symbol",
        color_continuous_scale=["#f7958a", "#1c2230", "#88e0b4"],
        color_continuous_midpoint=0,
        log_x=True,
        size_max=50,
        labels={
            "market_cap": "Market Cap (USD, log)",
            "change_pct_24h": "Cambio 24h (%)",
        },
    )
    fig.update_traces(
        textposition="top center",
        textfont=dict(size=9, color="#e6edf3"),
    )
    fig.add_hline(y=0, line_dash="dash", line_color="#484f58", line_width=1)
    _dl(fig, "Bubble Chart: Market Cap vs Cambio 24h (tamaño = Volumen)", height=450)
    fig.update_layout(
        xaxis=dict(gridcolor="#1c2230", tickfont=dict(color="#8b949e")),
        yaxis=dict(ticksuffix="%", gridcolor="#1c2230",
                   tickfont=dict(color="#8b949e")),
        coloraxis_colorbar=dict(
            title=dict(text="%", font=dict(color="#8b949e")),
            tickfont=dict(color="#8b949e"),
        ),
    )
    return fig


# ── Utils ─────────────────────────────────────────────────────────────────────

def _seccion(titulo: str):
    return html.Div([
        html.H4(titulo, className="fw-bold mb-3",
                style={"color": "var(--accent-blue)",
                       "borderBottom": "1px solid var(--border)",
                       "paddingBottom": "8px"})
    ], className="mt-2")


def _empty_fig(msg: str):
    fig = go.Figure()
    fig.add_annotation(
        text=msg, xref="paper", yref="paper",
        x=0.5, y=0.5, showarrow=False,
        font=dict(color="#8b949e", size=14)
    )
    fig.update_layout(
        paper_bgcolor="#161b22", plot_bgcolor="#161b22",
        height=300, margin=dict(t=40, b=20, l=20, r=20)
    )
    return fig


def _fmt_usd(v: float) -> str:
    if v >= 1e9: return f"${v/1e9:.1f}B"
    if v >= 1e6: return f"${v/1e6:.1f}M"
    return f"${v:,.0f}"

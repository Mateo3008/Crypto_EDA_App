# tabs/__init__.py
# Convierte /tabs en un paquete Python para importación modular desde app.py

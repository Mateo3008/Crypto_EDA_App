"""
app.py — v2
Crypto Market Dashboard
• Eliminada la pestaña de Predicción
• Auto-refresh cada 5 min con dcc.Interval
• 9 pestañas activas
"""

from dash import Dash, html, dcc, Input, Output
import dash_bootstrap_components as dbc

from tabs import (
    introduccion,
    contexto,
    problema,
    objetivos,
    marco_teorico,
    metodologia,
    resultados,
    limitaciones,
    conclusiones,
)

app = Dash(
    __name__,
    external_stylesheets=[dbc.themes.DARKLY],
    suppress_callback_exceptions=True,
    title="Crypto Dashboard",
    meta_tags=[{"name": "viewport",
                "content": "width=device-width, initial-scale=1"}],
)

TABS = [
    ("introduccion",  " Intro"),
    ("contexto",      " Mercado"),
    ("problema",      " Problema"),
    ("objetivos",     " Objetivos"),
    ("marco_teorico", " Marco"),
    ("metodologia",   " Método"),
    ("resultados",    " Resultados"),
    ("limitaciones",  " Límites"),
    ("conclusiones",  " Conclusiones"),
]

app.layout = html.Div([

    dcc.Interval(id="interval-refresh", interval=300_000, n_intervals=0),

    # ── Header ────────────────────────────────────────────────────────────
    html.Div([
        dbc.Container([
            dbc.Row([
                dbc.Col([
                    html.H1([
                        html.Span("◈ ", style={"color": "#f7c87e"}),
                        "Crypto Market Dashboard"
                    ], className="dash-title"),
                    html.P(
                        "Análisis en tiempo real · CryptoCompare API · Python + Dash",
                        className="dash-subtitle"
                    ),
                ], md=8),
                dbc.Col([
                    html.Div(
                        html.Div([
                            html.Span("", className="live-dot"),
                            " LIVE"
                        ], className="live-badge",
                           style={"float": "right", "marginTop": "16px",
                                  "display": "inline-flex"}),
                    )
                ], md=4),
            ])
        ], fluid=True)
    ], className="dash-header"),

    # ── Tabs ──────────────────────────────────────────────────────────────
    dbc.Container([
        dbc.Tabs(
            id="main-tabs",
            active_tab="introduccion",
            className="custom-tabs",
            children=[
                dbc.Tab(label=label, tab_id=tab_id)
                for tab_id, label in TABS
            ]
        ),
    ], fluid=True, style={"padding": "0"}),

    # ── Contenido ─────────────────────────────────────────────────────────
    html.Div(id="tab-content",
             style={"minHeight": "calc(100vh - 140px)"}),

], style={"background": "var(--bg-deep)", "minHeight": "100vh"})


@app.callback(
    Output("tab-content", "children"),
    Input("main-tabs",        "active_tab"),
    Input("interval-refresh", "n_intervals"),
)
def render_tab(active_tab: str, _n):
    mapping = {
        "introduccion" : introduccion.layout,
        "contexto"     : contexto.layout,
        "problema"     : problema.layout,
        "objetivos"    : objetivos.layout,
        "marco_teorico": marco_teorico.layout,
        "metodologia"  : metodologia.layout,
        "resultados"   : resultados.layout,
        "limitaciones" : limitaciones.layout,
        "conclusiones" : conclusiones.layout,
    }
    fn = mapping.get(active_tab)
    if fn:
        return fn()
    return html.Div("Pestaña no encontrada.",
                    className="text-center p-5",
                    style={"color": "var(--text-mid)"})


if __name__ == "__main__":
    app.run(debug=True, port=8050)
